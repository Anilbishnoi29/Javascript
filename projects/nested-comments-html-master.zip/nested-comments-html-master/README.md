# nested-comment-thread-html

Nested comment thread allows you to create a nested comment and sub-comment chain in Vanilla JavaScript.

![screen shot 2018-07-24 at 12 25 34 pm](https://user-images.githubusercontent.com/23554810/43121964-1b9a5e8a-8f3d-11e8-8d2e-bd119a7124f1.png)



### All this data is stored in the WebStorage of the browser

![screen shot 2018-07-24 at 12 24 58 pm](https://user-images.githubusercontent.com/23554810/43122027-4ca579a6-8f3d-11e8-8ddc-61df447d33c9.png)

## 'x' moments ago

![screen shot 2018-07-24 at 12 48 17 pm](https://user-images.githubusercontent.com/23554810/43122810-e7849b76-8f3f-11e8-9848-104bd798179d.png)


