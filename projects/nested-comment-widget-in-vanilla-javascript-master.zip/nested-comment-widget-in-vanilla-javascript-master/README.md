# nested-comment-widget-in-vanilla-javascript
nested comment widget in vanilla Javascript

This app is simple so you just need to download the app and run in browser.

Following functionality is implemented:
#1. Add new comment
#2. Reply any comment
#3. Edit any comment
#4. Like any comment
#5. Delete any comment

I would be glad to answer any query you have.


Thank you!!
Naveen Chaudhary
